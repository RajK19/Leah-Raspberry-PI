def print_green(text):
    print("\x1b[32m" + text + "\x1b[0m")
