from googleTTS import GoogleTTS

player = GoogleTTS("hello there, are you excited for the presentation or not?").play()
