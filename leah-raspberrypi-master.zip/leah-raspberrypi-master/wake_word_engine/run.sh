#!/bin/bash

python /home/leah/Documents/leah-final/wake_word_engine/wake_word.py
